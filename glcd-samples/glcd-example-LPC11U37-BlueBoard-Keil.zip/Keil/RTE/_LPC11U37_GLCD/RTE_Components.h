
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'blueboard_lpc11u37_glcd' 
 * Target:  'LPC11U37_GLCD' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "LPC11Uxx.h"


#endif /* RTE_COMPONENTS_H */
