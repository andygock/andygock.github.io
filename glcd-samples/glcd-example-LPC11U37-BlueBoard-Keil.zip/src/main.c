/**
 * GLCD demo for Blueboard LPC11U37/401 using Andy Gock's GLCD Library
 *
 * https://github.com/andygock/glcd
 *
 * LPC11U37/401 has 128KB Flash (len=0x20000), 10KB SRAM (len=0x2800)
 * Board running at 48 MHz clock (with 12 MHz crystal)
 *
 * \author Andy Gock
 */
#include <LPC11Uxx.h>
#include "glcd.h"
//#include "library/drivers/gpio.h" /* NXP peripheral driver */

#define LED_TEST1_PORT  0
#define LED_TEST1       (1U<<23)
#define LED_TEST2_PORT  0
#define LED_TEST2       (1U<<22)

/* SW1 Wakeup */
#define SW1_PORT  0
#define SW1       (1U<<16)

/* Ext switch */
#define SW3_PORT  0
#define SW3       (1U<<7)

/* ISP switch */
#define SW4_PORT  0
#define SW4       (1U<<1)

/* Function prototypes */
void delay_ms(uint32_t ms);
void led_blinky(void);
void test_switch(void);

/* Global variables */
volatile uint32_t ms_ticks = 0;
volatile uint32_t last_time = 0; /**< Last time of button press - used for debounce */
extern volatile uint8_t unit_test_return;

/** Systick function called every millisecond */
void SysTick_Handler(void)
{
    ms_ticks++;
}

/*
void HardFault_Handler(void) {
		__asm("BKPT");
}
*/

/** Delay by prescribed milliseconds */
void delay_ms(uint32_t ms)
{
    uint32_t now = ms_ticks;
    while ((ms_ticks-now) < ms);
}

void FLEX_INT1_IRQHandler(void)
{
	
	if ( LPC_GPIO_PIN_INT->FALL & (1U<<1) ) {

		LPC_GPIO_PIN_INT->FALL = (1U<<1); /* Clear falling edge detect */
		
		/* Ignore if last falling edge was < 300ms ago - debounce */
		if ( (ms_ticks - last_time) < 300 ) {
			last_time = ms_ticks;
			return;
		}
		
		/* Toggle LED status */
		LPC_GPIO->NOT[LED_TEST1_PORT] |= LED_TEST1;
		
#if 0
		/* This could be used instead, if using peripheral library */
		if ( GPIOGetPinValue( 0, 23 ) ) {
			GPIOSetBitValue( 0, 23, 0 );
		} else {
			GPIOSetBitValue( 0, 23, 1 );
		}
#endif
		
		/* Set global var to let test routines know to return - test routines clear it when they return */
		unit_test_return = 1;
	}
	
	/* Clear detection - needs to be run at end of ISR */
	LPC_GPIO_PIN_INT->IST = (1U<<1);
	
	/* Save last time */
	last_time = ms_ticks;
	
	return;
}

int main(void)
{
	/* Set up system clocks */
	SystemInit();
	SystemCoreClockUpdate();
	SysTick_Config(SystemCoreClock/1000);

	/* Enable GPIO clock and GRPO pin interrupts register interface */
	LPC_SYSCON->SYSAHBCLKCTRL |= (1<<6) | (1<<19);

	//led_blinky();
	
	/* Reconfigure these SWD pins as GPIO used by LCD */
	LPC_SYSCON->SYSAHBCLKCTRL |= (1<<16); /* Enable IO configuration block */
	LPC_IOCON->TMS_PIO0_12 |= 0x1;
	LPC_IOCON->TDO_PIO0_13 |= 0x1;
	LPC_IOCON->TRST_PIO0_14 |= 0x1;
	
	/* Turn on LCD backlight (P1.14) */
	LPC_GPIO->DIR[1] |= (1<<14);
	LPC_GPIO->SET[1] |= (1<<14);

	/* Set LED pin as output, we'll later toggle the LED by button press */
	LPC_GPIO->DIR[LED_TEST1_PORT] |= LED_TEST1;
	
#if 0
	/* This can be used if using NXP peripheral library */
	GPIOInit();
	GPIOSetDir( 0, 23, 1 );	  // TEST_LED1 D3 
	GPIOSetDir(PORT0, 7, 0);  // External switch(PIO0_7) / SW3
	GPIOSetFlexInterrupt( CHANNEL1, PORT0, 7, 0, 0 );
	GPIOFlexIntEnable( CHANNEL1, 0 );
#endif

	/* Setup GPIO pin change interrupts */
	LPC_SYSCON->PINTSEL[1] = 7;         /* Select pin for pin interrupt ch 1  */
	NVIC_EnableIRQ(FLEX_INT1_IRQn);     /* Enable interrupts                  */
	LPC_GPIO_PIN_INT->ISEL &= ~(1<<1);  /* Ch 1 edge trigger                  */
	LPC_GPIO_PIN_INT->IENF |=  (1<<1);  /* On falling edge                    */
	LPC_GPIO_PIN_INT->SIENF |= (1U<<1); /* Enable falling edge interrupts     */
	
	glcd_init();
	//glcd_command(0xA5); while(1); /* Turn on all dot - test whether LCD has initialised properly */
	
	/* Loop through each demo, each demo will return when unit_test_return is set by pin change interrupt */
	while(1) {
		glcd_test_circles();
		glcd_test_counter_and_graph();
		glcd_test_glcdutils();
		glcd_test_text_up_down();
		glcd_test_tiny_text();
		glcd_test_hello_world();
		glcd_test_rectangles();
		glcd_test_scrolling_graph();
		glcd_test_bitmap_128x64();
	}
	
}

/** Blink some LEDs to make sure code is at least working */
void led_blinky(void)
{
	/* Set LED pin as output */
	LPC_GPIO->DIR[LED_TEST1_PORT] |= LED_TEST1;
	LPC_GPIO->DIR[LED_TEST1_PORT] |= LED_TEST2;

	while (1) {
		/* Method 1 */
		LPC_GPIO->CLR[LED_TEST1_PORT] |= LED_TEST1;  /* Pin low, LED on   */
		LPC_GPIO->SET[LED_TEST1_PORT] |= LED_TEST2;  /* Pin high, LED off   */
		delay_ms(500);
		LPC_GPIO->SET[LED_TEST1_PORT] |= LED_TEST1; /* Pin high, LED off */
		LPC_GPIO->CLR[LED_TEST1_PORT] |= LED_TEST2; /* Pin low, LED on */
		delay_ms(500);
	}	
}

void test_switch(void)
{
	/* Enable push button switch - set as input */
	LPC_GPIO->DIR[SW3_PORT] &= ~SW3;

	/* Set LED pin as output */
	LPC_GPIO->DIR[LED_TEST1_PORT] |= LED_TEST1;
	
	while (1) {
		if (LPC_GPIO->PIN[SW3_PORT] & SW3) {
			/* Button up, LED off */
			LPC_GPIO->SET[LED_TEST1_PORT] |= LED_TEST1;
		} else {
			/* Button down, LED on */
			LPC_GPIO->CLR[LED_TEST1_PORT] |= LED_TEST1;
		}
	}	
}
