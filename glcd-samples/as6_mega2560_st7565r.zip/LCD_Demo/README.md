glcd Library Demo on AVR
========================

This is on a custom PCB which we'll call 'PP_Board'. Work on the glcd sometimes is taken up on a branch with the same name.

The connections of the LCD to the MCU are:

SS#   PG0
RESET PG1
A0    PC0
SCK   PB1
MOSI  PB2

BACKLIGHT PL3 (not directly)