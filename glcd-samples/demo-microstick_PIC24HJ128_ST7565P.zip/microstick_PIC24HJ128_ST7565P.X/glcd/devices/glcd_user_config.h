#ifndef GLCD_USER_CONFIG_H
#define GLCD_USER_CONFIG_H

/*
 * To use this, you must define "GLCD_DEVICE_USER" in your compiler options.
 * This file is not included in the glcd distribution. It is for custom defined
 * functions. This means if you wish to update glcd, you can overwrite the
 * glcd directory, and still maintain your custom settings such as pin config,
 * etc.
 */


#endif