/* PCD8544 LCD controller demo on NXP LPC1114 MCU
 * Compatible with Nokia 5110 96x48 LCD
 *
 * \author Andy Gock
 *
 * Dev board used: ZERO Z111xP Cortex-M0 LPC1114 board
 * Compiler: ARM GCC
 *
 * Physical configuration and drivers need to be set in:
 *   library/controllers/devices/LPC111x.h
 *
 * Board is running at 48 MHz
 *
 */

#include <LPC11xx.h>
#include <stdio.h>
#include "library/glcd/glcd.h"
#include "library/drivers/driver_config.h"

// Function prototypes
void delay_ms(uint32_t ms);
static void test_spi(void);
static void pin_blink(void);
static void led_blink(void);

// Global variables
volatile uint32_t ms_ticks = 0;

int main(void)
{
	/* Setup the microcontroller system. */
	SystemInit();

	SystemCoreClockUpdate();
	SysTick_Config(SystemCoreClock/1000);

	// enable GPIO clock
	LPC_SYSCON->SYSAHBCLKCTRL |= (1<<6);

	// set P2.10 high - use this as power to LCD
	// LCD requires very little current, perhaps 1mA or so
	LPC_GPIO2->DIR  |= (1<<10);
	LPC_GPIO2->DATA  |= (1<<10);

	// note: clock is at 48MHz
	// max SPI clock is 4MHz for controller
	// our actual SPI clock set is 1.5 MHz

	glcd_init();
	glcd_set_contrast(50);
	glcd_clear();

	// Select demo to run
	//glcd_test_circles();
	glcd_test_counter_and_graph();
	//glcd_test_text_up_down();

	return 0;
}

/** Override systick interrupt */
void SysTick_Handler(void) {
    ms_ticks++;
}

/** Delay by prescribed milliseconds */
void delay_ms(uint32_t ms) {
    uint32_t now = ms_ticks;
    while ((ms_ticks-now) < ms);
}

/** Test SPI function */
static void test_spi(void)
{
	while(1) {
		glcd_spi_write(0xf0);
		glcd_spi_write(0x0f);
		delay_ms(1000);
	}
}

/** Blinking a pin, to test if it works */
static void pin_blink(void)
{
	// testing SS pin, make sure it works
	LPC_GPIO2->DIR  |= (1<<9);
	while(1) {
		LPC_GPIO2->DATA |= (1<<9);
		LPC_GPIO2->DATA &= ~(1<<9);
	}
}

/** Blink LED! (PIO 3.5) */
static void led_blink(void)
{
	// Blink LED routine
	LPC_GPIO3->DIR |= (1<<5);      // pin output

	while (1) {
		LPC_GPIO3->DATA &= ~(1<<5);  // pin low, LED on
		delay_ms(100);
		LPC_GPIO3->DATA |=  (1<<5);  // pin high, LED off
		delay_ms(900);
	}
}
