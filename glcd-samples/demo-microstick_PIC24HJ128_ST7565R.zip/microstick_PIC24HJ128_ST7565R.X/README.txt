Pin connections for this demo

( LCD => MCU )

MISO / DOUT => B14
SCK => B15
SS => B2
A0 => B3
RESET => A2

Connect 3.3V, GND amd LED backlight pins as required.