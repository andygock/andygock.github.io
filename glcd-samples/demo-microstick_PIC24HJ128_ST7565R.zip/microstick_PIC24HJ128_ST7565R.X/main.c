/*
 * Microstick demo with graphic LCD
 *  - PIC24HJ128 MCU
 *  - Newhaven display NHD-C12832A1Z-FSW-FBW-3V with ST7565R chipset
 *  - Graphic LCD library from agock.com
 */

//#define FOSC    (7370000ULL) // Fast RC internal oscillator 7.37 MHz

// This is what we use: (FOSC defined in compiler options)
//#define FOSC    (46062500ULL) // Fast RC osciilator with PLL, default settings: 7.37 MHz /2 *50 /4 = approx 46 MHz
#define FCY     (FOSC/2)

// SPI prescale is set at 4 (PIC24H.h)
// LCD SCK runs at FCY/4 Hz = approx 5.75 MHz

// LED on Microstick II board
#define LED  	 _LATA0
#define LED_TRIS _TRISA0

#include <stdint.h>
#include <xc.h>
#include <libpic30.h>
#include "main.h"
#include "glcd.h"

/* Global variables from other files */
extern volatile uint8_t unit_test_return; /* from glcd module */

/* Our global variables */
volatile uint32_t tick; /* this tick counts every 100ms */

/* Function prototype for Timer 1 ISR */
void __attribute__((__interrupt__, __auto_psv__)) _T1Interrupt(void);

/* Other function prototypes */
static void test_spi_counter(void);
static void tick_init(void);

/** Send 8 bit byte out the SPI1 port every 100ms, increments byte each time.
 *  This is just to test our SPI init code, make sure data is being placed on
 *  the SPI output pins.
 */
void test_spi_counter(void)
{

	/* Set up remappable outputs for PIC24H, SPI: DO and SCK */
	OSCCONbits.IOLOCK = 0;
	REGISTER_MAP_SPI_DO = 0b00111; /* Set as SPI DO */
	REGISTER_MAP_SPI_SCK = 0b01000; /* Set as SCK */
	OSCCONbits.IOLOCK = 1;

	/* Set direction of various pins to OUTPUT */
	CONTROLLER_MOSI_TRIS = 0;
	CONTROLLER_SCK_TRIS = 0;
	CONTROLLER_SS_TRIS = 0;
	CONTROLLER_A0_TRIS = 0;
	CONTROLLER_RST_TRIS = 0;

	/* SPI setup based on sample code from datasheet */
	/* The following code shows the SPI register configuration for Master mode */
	IFS0bits.SPI1IF = 0; /* Clear the Interrupt Flag */
	IEC0bits.SPI1IE = 0; /* Disable the Interrupt */

	/* SPI1CON1 Register Settings */
	SPI1CON1bits.DISSCK = 0; /* Internal Serial Clock is Enabled */
	SPI1CON1bits.DISSDO = 0; /* SDOx pin is controlled by the module */
	SPI1CON1bits.MODE16 = 0; /* Communication is word-wide (16 bits) */
	SPI1CON1bits.SMP = 0;    /* Input data is sampled at the middle of data */
	SPI1CON1bits.CKE = 0;    /* Serial output data changes on transition */
	SPI1CON1bits.CKP = 0;    /* Idle state for clock is a low level */
	SPI1CON1bits.PPRE = 0b11;  /* Primary prescale = 1:1 */
	SPI1CON1bits.SPRE = 0b001; /* Secondary prescale = 4:1 */
	SPI1CON1bits.MSTEN = 1;  /* Master mode Enabled */
	SPI1STATbits.SPIEN = 1;  /* Enable SPI module */

	uint8_t counter;

	while(1) {
		while (SPI1STATbits.SPITBF); /* Loop until TX buffer is empty */
		SPI1BUF = (counter & 0x00FF); /* Write data to be transmitted */
		while(!SPI1STATbits.SPIRBF); /* Wait until TX finished */

		uint8_t read;
		read = SPI1BUF; /* Throw away the data (not sure if it is neccesary, to force reading of SPI1BUF) */

		__delay_ms(500); /* Wait 100 ms */

		counter++;
	}
}

/* Timer 1 interrupt, also our tick timer */
void __attribute__((__interrupt__, __auto_psv__)) _T1Interrupt(void)
{
    /* Clear Timer 1 interrupt flag */
    _T1IF = 0;

	/* Increment tick counter */
	tick++;

    /* Toggle LED every second, just so we know this ISR is working */
	if (tick % 10 == 0) {
		LED ^= 1;
	}

	if (tick % 50 == 0) {
		/* Every 5s, change the glcd uint test */
		unit_test_return = 1; /* when set high, unit test will return */
	}
}

/* Initialise Timer 1 as our tick timer */
void tick_init(void) {
	/*
	 *  Configure Timer 1.
	 *
	 *  Tcy = 10.9ns
	 *  Period = PR1 * prescaler * Tcy = 9000 * 256 * 21.7ns = 100ms
	 */
	
	T1CON = 0;            // Clear Timer 1 configuration
	T1CONbits.TCKPS = 3;  // Set timer 1 prescaler (0=1:1, 1=1:8, 2=1:64, 3=1:256)
	PR1 = 9000;           // Set Timer 1 period (max value is 65535)
	_T1IP = 1;            // Set Timer 1 interrupt priority
	_T1IF = 0;            // Clear Timer 1 interrupt flag
	_T1IE = 1;            // Enable Timer 1 interrupt
	T1CONbits.TON = 1;    // Turn on Timer 1
}

int main() 
{
    /* Map SPI pins */

    // Initialize the LED. This symbol is defined in system_config.h
    LED_TRIS = 0;

	//test_spi_counter(); /* Test function, never returns */

	tick_init();

	glcd_init();

	/* Run unit test demo, and switch every 5s (timer ISR takes care of this */
    while (1) 
    {
 		glcd_test_tiny_text();
		glcd_test_text_up_down();
		glcd_test_counter_and_graph();
		glcd_test_circles();
		glcd_test_scrolling_graph();
		glcd_test_glcdutils();
		glcd_test_rectangles();
    }
    
    return 0;
}
