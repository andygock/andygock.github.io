
// DOM-IGNORE-END
//
#ifndef MAIN_H
#define	MAIN_H


// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************
/*  This section lists the other files that are included in this file.
*/
#include "system_config/microstick2_pic24hj128gp502/system_config.h"

#ifdef	__cplusplus
extern "C" {
#endif


    

#ifdef	__cplusplus
}
#endif

#endif	/* MAIN_H */

/*******************************************************************************
 End of File
*/

